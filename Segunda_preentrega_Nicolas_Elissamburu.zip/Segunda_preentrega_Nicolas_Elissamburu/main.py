from claseclientes import Clientes

cliente1 = Clientes("Nicolas", "Elissamburu", 28, "nico.eliss@hotmail.com")
print(cliente1)  
cliente1.imprimir_informacion()  