class Clientes:
    def __init__(self, nombre, apellido, edad, email):
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad
        self.email = email

    def imprimir_informacion(self):
        print(f"Nombre: {self.nombre} {self.apellido}")
        print(f"Edad: {self.edad}")
        print(f"Email: {self.email}")

    def es_mayor_de_edad(self):
        return self.edad >= 18

    def __str__(self):
        return f"{self.nombre} {self.apellido}"